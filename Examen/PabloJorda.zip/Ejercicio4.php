<?php
$num=91;

if($num%2!=0) $num=$num-1;

while ($num>=0){
    echo $num." ";
    $num=$num-2;
}

?>