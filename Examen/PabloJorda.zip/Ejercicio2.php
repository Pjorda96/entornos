<?php
$num1=5;
$num2=3;
$res=1;

for ($i=1;$i<=$num2;$i++){
    $res=$res*$num1;
}
echo $res;
?>